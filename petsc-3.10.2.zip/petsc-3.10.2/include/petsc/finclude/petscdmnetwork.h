
!
!  Include file for Fortran use of the DMNetwork
!
#if !defined (__PETSCDMNETWORKDEF_H)
#define __PETSCDMNETWORKDEF_H

#define DMNetworkMonitor PetscFortranAddr

#endif
